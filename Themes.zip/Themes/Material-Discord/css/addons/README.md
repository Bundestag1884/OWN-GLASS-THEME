# Material Discord Add-on Themes - [![Paypal][paypal-logo]][paypal-url] [![GitHub][github-logo]][github-url]

* [Solid Icons](https://github.com/CapnKitten/BetterDiscord/tree/master/Themes/Material-Discord/css/addons/icons) - Converts the outline icons in Material Discord to solid icons. Requires Material Discord.
* [Old Message Bubbles](https://github.com/CapnKitten/BetterDiscord/tree/master/Themes/Material-Discord/css/addons/messages) - Changes the message bubbles and main textbox to an older version before Material Design 2.0. Requires Material Discord.
* [Material You](https://github.com/CapnKitten/BetterDiscord/tree/master/Themes/Material-Discord/css/addons/material-you) - Converts the Material Discord color scheme to resemble that of Material You based on the accent color. Requires Material Discord.
* [Custom Themes](https://github.com/CapnKitten/BetterDiscord/tree/master/Themes/Material-Discord/css/addons/custom-themes) - Allows the custom Discord themes to work with Material Discord. Requires Material Discord.


[paypal-logo]: https://img.shields.io/static/v1?label=PayPal&message=Donate&style=flat&logo=paypal&color=blue
[paypal-url]: https://paypal.me/capnkitten

[github-logo]: https://img.shields.io/static/v1?label=GitHub&message=Sponsor&style=flat&logo=github&color=black
[github-url]: https://github.com/sponsors/CapnKitten
